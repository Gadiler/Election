package exceptions;

@SuppressWarnings("serial")
public class CitizenException extends Exception{

	public CitizenException(String str) {
		super(str);
	}
}
