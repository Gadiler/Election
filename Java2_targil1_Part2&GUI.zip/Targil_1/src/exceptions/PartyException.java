package exceptions;

@SuppressWarnings("serial")
public class PartyException extends Exception {
	
	public PartyException(String str) {
		super(str);
	}
	
}
