package exceptions;

@SuppressWarnings("serial")
public class VoteException extends CitizenException {

	public VoteException(String str) {
		super(str);
	}

}
