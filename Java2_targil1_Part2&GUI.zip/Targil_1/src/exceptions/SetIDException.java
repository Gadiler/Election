package exceptions;

@SuppressWarnings("serial")
public class SetIDException extends CitizenException {

	public SetIDException(String str) {
		super(str);
	}

}
