package exceptions;

@SuppressWarnings("serial")
public class AddContenderException extends CitizenException {
	
	public AddContenderException(String str) {
		super(str);
	}
}
