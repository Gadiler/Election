package interfaces;

public interface Sickable {
	
	void sickFunc();
}
