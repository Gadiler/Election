package mvc;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GUI implements ActionListener{
	private JFrame frame;
	private JLabel label;
	private JPanel panel;
	private JComboBox box;
	
	public GUI() {
		frame = new JFrame();
		label = new JLabel();
		panel = new JPanel();
		box = new JComboBox();
		
		panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 10, 30));
		panel.setLayout(new GridLayout(0, 1));
		panel.add(label);
		
		frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Election");
		frame.pack();
		frame.setVisible(true);
		
//		box.
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
}
